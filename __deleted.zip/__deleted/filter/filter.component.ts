
import { Component } from '@angular/core'
import { HttpClient} from '@angular/common/http';

import { InteractionService }      from '../../shared/interaction.service';
import { RequestService }           from '../../shared/request.service';

import { ComboboxComponent }        from '../../elements/combobox/combobox.component';
import { TextfieldComponent }        from '../../elements/textfield/textfield.component';
import { FieldsetComponent }        from '../../elements/fieldset/fieldset.component';

import {NgModule,Input,ComponentFactory,ComponentRef, ComponentFactoryResolver, ViewContainerRef, ChangeDetectorRef, TemplateRef, ViewChild, Output, EventEmitter} from '@angular/core'
//import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
    selector: 'filter-place',
    templateUrl: './filter.component.html',
    styleUrls: ['./filter.component.css']
})
export class FilterPlaceComponent {
    filterItems: any[] = [];

    name:string = '';

    @ViewChild("elementsContainer", { read: ViewContainerRef }) container;
    componentRef: ComponentRef<any>;

    constructor(private resolver: ComponentFactoryResolver,
                private interactionService:  InteractionService,
                private request: RequestService/*,
                private fb: FormBuilder*/){
        interactionService.runGetFilterSubject.subscribe(data => this.getFilter(data));
        interactionService.runClearAllSubject.subscribe(() => this.clearAll());

        /*this.rForm = fb.group({
            'name' : [null, Validators.required],
            'description' : [null, Validators.compose([Validators.required, Validators.minLength(30), Validators.maxLength(500)])],
            'validate' : ''
        });*/

    }

    onClickFilterRequest(){
        let fields = this.getAllFields();
    }

    onClickFilterClear(){
    }

    getAllFields(){

    }

    addPost(){
    }


    clearAll(){
        this.filterItems = [];
    }

    getFilter(link){
        this.request.getFilter((data => this.setFilter(data)), link);
    }

    setFilter(data){
        if(data && data instanceof Array) this.filterItems = data;

        data.reverse();

        data.forEach(fieldset => {
                this.createComponent('fieldset', fieldset);
        });

        let fieldsObj = {};

        data.forEach(fieldset => {
            fieldset['filters'].forEach(item => {

                fieldsObj[item.name] = item.value || null;

                //this.createComponent(item['fieldType'], item);
            })
        });

        //this.createComponent('combobox', data[1]['filters'][1]);
        //this.createComponent('textfield', data[1]['filters'][0]);
    }

    createComponent(type: string, data: any) {
        //this.container.clear();
        let factory: ComponentFactory<any>;

        //As we say before the resolveComponentFactory() method takes a
        // component and returns the recipe for how to create a component.
        if(type === 'combobox')  factory = this.resolver.resolveComponentFactory(ComboboxComponent);
        if(type === 'textfield') factory = this.resolver.resolveComponentFactory(TextfieldComponent);
        if(type === 'fieldset') factory = this.resolver.resolveComponentFactory(FieldsetComponent);

        if(!factory) return;

        //We are calling the createComponent() method with the recipe.
        // Internally this method will call the create() method from the
        // factory and will append the component as a sibling to our container.
        this.componentRef = this.container.createComponent(factory, data);

        //Now we have a reference to our new component, and we can set the type Input.
        this.componentRef.instance.data = data;
        this.componentRef.instance.name = 'NAME';

        //You can also subscribe to a component Output like this:
        this.componentRef.instance.output.subscribe(event => console.log(event));

    }

    ngOnDestroy() {
        this.componentRef.destroy();
    }

}
