import { TestBed, async } from '@angular/core/testing';
import { AppComponent } from './app.component';

import { MenuPlaceComponent }   from './places/menu/menu.component';
import { FilterPlaceComponent } from './places/filter/filter.component';
import { CenterPlaceComponent } from './places/center/center.component';
import { ServicePlaceComponent } from './places/service/service.component';
import { SummaryPlaceComponent } from './places/summary/summary.component';
import { TabPlaceComponent }     from './places/tab/tab.component';
import { FilterButtonComponent }     from './places/filterbutton/filterbutton.component';

import { DynamicFormComponent }         from './dynamic-form/dynamic-form.component';
import { DynamicFormQuestionComponent } from './dynamic-form/dynamic-form-question.component';
import { CdkTableModule } from '@angular/cdk/table';

import {DataSource} from '@angular/cdk/table';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import {
    MatAutocompleteModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatCheckboxModule,
    MatChipsModule,
    MatDatepickerModule,
    MatDialogModule,
    MatExpansionModule,
    MatGridListModule,
    MatIconModule,
    MatInputModule,
    MatListModule,
    MatMenuModule,
    MatPaginatorModule,
    MatProgressBarModule,
    MatProgressSpinnerModule,
    MatRadioModule,
    MatRippleModule,
    MatSelectModule,
    MatSidenavModule,
    MatSliderModule,
    MatSlideToggleModule,
    MatSnackBarModule,
    MatSortModule,
    MatTableModule,
    MatTabsModule,
    MatToolbarModule,
    MatTooltipModule,
    MatStepperModule,
} from '@angular/material';

import { MatCardModule, MatNativeDateModule } from "@angular/material";

import { InteractionService }    from './shared/interaction.service';
import { RequestService }        from './shared/request.service';

import { HttpClientModule, HttpClient, HttpHandler }   from '@angular/common/http';

describe('AppComponent', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
        providers: [
            InteractionService,
            RequestService,
            HttpClient,
            HttpClientModule,
            HttpHandler
        ],

        imports: [
            FormsModule,
            ReactiveFormsModule,

            CdkTableModule,
            MatAutocompleteModule,
            MatButtonModule,
            MatButtonToggleModule,
            MatCardModule,
            MatCheckboxModule,
            MatChipsModule,
            MatStepperModule,
            MatDatepickerModule,
            MatDialogModule,
            MatExpansionModule,
            MatGridListModule,
            MatIconModule,
            MatInputModule,
            MatListModule,
            MatMenuModule,
            MatNativeDateModule,
            MatPaginatorModule,
            MatProgressBarModule,
            MatProgressSpinnerModule,
            MatRadioModule,
            MatRippleModule,
            MatSelectModule,
            MatSidenavModule,
            MatSliderModule,
            MatSlideToggleModule,
            MatSnackBarModule,
            MatSortModule,
            MatTableModule,
            MatTabsModule,
            MatToolbarModule,
            MatTooltipModule,
        ],
        /*exports: [
            CdkTableModule
        ],*/
      declarations: [
          AppComponent,
          MenuPlaceComponent,
          FilterPlaceComponent,
          CenterPlaceComponent,
          ServicePlaceComponent,
          SummaryPlaceComponent,
          TabPlaceComponent,
          FilterButtonComponent,

          DynamicFormComponent,
          DynamicFormQuestionComponent
      ],
    }).compileComponents();
  });


  it('Должен создать приложение', async(() => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app).toBeTruthy();
  }));
  it(`Должен быть титул 'Incoming'`, async(() => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.debugElement.componentInstance;
      console.info('app.title - ',app);
    expect(app.title).toEqual('Incoming');
  }));
  /*it('should render title in a h1 tag', async(() => {
    const fixture = TestBed.createComponent(AppComponent);
    fixture.detectChanges();
    const compiled = fixture.debugElement.nativeElement;
    expect(compiled.querySelector('h1').textContent).toContain('Welcome to app!');
  }));*/
});
