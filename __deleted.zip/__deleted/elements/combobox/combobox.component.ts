import {Component, NgModule,Input,ComponentFactory,ComponentRef, ComponentFactoryResolver, ViewContainerRef, ChangeDetectorRef, TemplateRef, ViewChild, Output, EventEmitter} from '@angular/core'

@Component({
    selector: 'combobox-element-place',
    templateUrl: './combobox.component.html',
    styleUrls: ['./combobox.component.css']
})

export class ComboboxComponent {
    @Input() data: any;
    @Output() output = new EventEmitter();

}