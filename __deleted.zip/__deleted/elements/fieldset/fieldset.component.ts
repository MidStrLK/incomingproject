import {Component, NgModule,Input,ComponentFactory,ComponentRef, ComponentFactoryResolver, ViewContainerRef, ChangeDetectorRef, TemplateRef, ViewChild, Output, EventEmitter, OnInit} from '@angular/core'


import { ComboboxComponent }        from '../../elements/combobox/combobox.component';
import { TextfieldComponent }        from '../../elements/textfield/textfield.component';

@Component({
    selector: 'fieldset-element-place',
    templateUrl: './fieldset.component.html',
    styleUrls: ['./fieldset.component.css']
})

export class FieldsetComponent {
    private _data: any;
    @Input() data: any;
    @Output() output = new EventEmitter();


    @ViewChild("elementsContainer", { read: ViewContainerRef }) container;
    componentRef: ComponentRef<any>;

    constructor(private resolver: ComponentFactoryResolver){}

    ngOnInit() {
        this.setFilter(this.data['filters'])
    }

    setFilter(data) {
        //if(data && data instanceof Array) this.filterItems = data;


        data.reverse();

        data.forEach(item => {
            this.createComponent(item['fieldType'], item);
        });

        //this.createComponent('combobox', data[1]['filters'][1]);
        //this.createComponent('textfield', data[1]['filters'][0]);
    }

    createComponent(type: string, data: any) {
        //this.container.clear();
        let factory: ComponentFactory<any>;

        //As we say before the resolveComponentFactory() method takes a
        // component and returns the recipe for how to create a component.
        if(type === 'combobox')  factory = this.resolver.resolveComponentFactory(ComboboxComponent);
        if(type === 'textfield') factory = this.resolver.resolveComponentFactory(TextfieldComponent);
        if(type === 'fieldset') factory = this.resolver.resolveComponentFactory(FieldsetComponent);

        if(!factory) return;

        //We are calling the createComponent() method with the recipe.
        // Internally this method will call the create() method from the
        // factory and will append the component as a sibling to our container.
        this.componentRef = this.container.createComponent(factory, data);

        //Now we have a reference to our new component, and we can set the type Input.
        this.componentRef.instance.data = data;
        this.componentRef.instance.name = 'NAME';

        //You can also subscribe to a component Output like this:
        this.componentRef.instance.output.subscribe(event => console.log(event));

    }

    ngOnDestroy() {
        this.componentRef.destroy();
    }
}