import {Component, NgModule,Input,ComponentFactory,ComponentRef, ComponentFactoryResolver, ViewContainerRef, ChangeDetectorRef, TemplateRef, ViewChild, Output, EventEmitter} from '@angular/core'

@Component({
    selector: 'textfield-element-place',
    templateUrl: './textfield.component.html',
    styleUrls: ['./textfield.component.css']
})

export class TextfieldComponent {
    @Input() data: any;
    @Output() output = new EventEmitter();

}