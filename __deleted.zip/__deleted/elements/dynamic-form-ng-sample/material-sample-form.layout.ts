export const MATERIAL_SAMPLE_FORM_LAYOUT = {

    "addressStreet": {
        element: {
            host: "material-form-group"
        }
    }
};