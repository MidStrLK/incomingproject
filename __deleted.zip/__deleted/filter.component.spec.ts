/*
    TestBed is the first and most important of the Angular testing utilities.
]It creates an Angular testing module—an @NgModule class—that you configure
with the configureTestingModule method to produce the module environment for
the class you want to test. In effect, you detach the tested component from
its own application module and re-attach it to a dynamically-constructed
Angular test module tailored specifically for this battery of tests.

    Call configureTestingModule within a beforeEach so that TestBed can reset
itself to a base state before each test runs.
*/



import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By }              from '@angular/platform-browser';
import { DebugElement }    from '@angular/core';

import { FilterPlaceComponent } from './filter.component';


import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DynamicFormComponent }      from '../../dynamic-form/dynamic-form.component';
import { DynamicFormQuestionComponent }      from '../../dynamic-form/dynamic-form-question.component';
import { QuestionControlService }    from '../../dynamic-form/question-control.service';
import { QuestionBase }              from '../../dynamic-form/question-base';

import { InteractionService }      from '../../shared/interaction.service';
import { RequestService }           from '../../shared/request.service';

import { MatFormFieldModule, MatSelectModule } from '@angular/material';
import { MockBackend } from '@angular/http/testing';

describe('FilterPlaceComponent (inline template)', () => {

    let comp:    FilterPlaceComponent;
    let fixture: ComponentFixture<FilterPlaceComponent>;
    let de:      DebugElement;
    let el:      HTMLElement;
    /*let mockSomeService = {
        runGetFilterSubject: () => {}

    };*/

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers:    [
                {provide: InteractionService/*, useValue: mockSomeService*/},
                {provide: RequestService/*, useValue: mockSomeService*/}
            ],
            imports: [
                FormsModule,
                ReactiveFormsModule,
                MatFormFieldModule,
                MatSelectModule
            ],
            declarations: [
                DynamicFormQuestionComponent,
                DynamicFormComponent,
                FilterPlaceComponent
            ], // declare the test component
        });

        /*After configuring TestBed, you tell it to create an instance
         of the component-under-test. In this example, TestBed.createComponent
         creates an instance of BannerComponent and returns a component test fixture.*/
        fixture = TestBed.createComponent(FilterPlaceComponent);

        comp = fixture['componentInstance']; // FilterPlaceComponent test instance

        // query for the title <h1> by CSS element selector
        de = fixture['debugElement'].query(By.css('.test-karma-span'));
        el = de['nativeElement'];


    });

    /*it('1st tests', () => {
        spyOn(mockSomeService, 'runGetFilterSubject').and.returnValue({ subscribe: () => {} });
        it('true is true', () => expect(true).toBe(true));
    });*/


    it('test should wait for FancyService.getTimeoutValue',
        async(inject([InteractionService], (service: InteractionService) => {
console.info('service - ',service);
            service.runGetFilterSubject().then(
                value => expect(value).toBe('timeout value')
            );
        })));

    /*it('#getObservableValue should return observable value', (done: DoneFn) => {
        let interactionService = new InteractionService();

        console.info('interactionService - ',interactionService);
        console.info('interactionService.runGetFilterSubject - ',interactionService.runGetFilterSubject);
        interactionService.runGetFilterSubject().subscribe(value => {
            expect(value).toBe('observable value');
            done();
        });
    });*/

    //this.service.getSome().subscribe(x => this.invokeHere(x));
    //interactionService.runGetFilterSubject.subscribe(data => this.getFilter(data));
    /*it('test observable', inject([MockBackend], (mockBackend: MockBackend) => {
        mockBackend.connections.subscribe((connection: MockConnection) => {
            connection.mockError(new Error());
        });
        interactionService.runGetFilterSubject()
            .subscribe(() => { },(err) => {
                // your test
            });
    }));*/

    /*it('should display original title', () => {
        //fixture['detectChanges']();
        expect(el.textContent).toContain(comp.testtitle);
    });

    it('should display a different test title', () => {
        comp['testtitle'] = 'Test Title';
        //fixture['detectChanges']();
        expect(el.textContent).toContain('Test Title');
    });*/
});